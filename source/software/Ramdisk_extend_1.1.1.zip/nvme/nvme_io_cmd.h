

#ifndef __NVME_IO_CMD_H_
#define __NVME_IO_CMD_H_


void handle_nvme_io_cmd(NVME_COMMAND *nvmeCmd);

#endif	//__NVME_IO_CMD_H_
