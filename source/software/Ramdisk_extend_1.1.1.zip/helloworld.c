
/*
 * test.c
 *
 *  Created on: Jul 28, 2014
 *      Author: yjjo
 */





#include "xil_cache.h"
#include "xil_exception.h"
#include "xil_mmu.h"
#include "xparameters_ps.h"
#include "xscugic_hw.h"
#include "xscugic.h"
#include "xil_printf.h"
#include "debug.h"

#include "nvme.h"
#include "nvme_main.h"
#include "host_lld.h"


XScuGic GicInstance;

int main()
{
	XScuGic_Config *IntcConfig;

	Xil_ICacheEnable();
	Xil_DCacheDisable();

	xil_printf("\r\nhello world!!!\r\n");


	Xil_ExceptionInit();

	IntcConfig = XScuGic_LookupConfig(XPAR_SCUGIC_SINGLE_DEVICE_ID);
	XScuGic_CfgInitialize(&GicInstance, IntcConfig, IntcConfig->CpuBaseAddress);
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
								(Xil_ExceptionHandler)XScuGic_InterruptHandler,
								&GicInstance);

	XScuGic_Connect(&GicInstance, XPAR_FABRIC_NVMEHOSTCONTROLLER_0_DEV_IRQ_ASSERT_INTR,
					(Xil_ExceptionHandler)dev_irq_handler,
					(void *)0);

	XScuGic_Enable(&GicInstance, XPAR_FABRIC_NVMEHOSTCONTROLLER_0_DEV_IRQ_ASSERT_INTR);

	// Enable interrupts in the Processor.
	Xil_ExceptionEnableMask(XIL_EXCEPTION_IRQ);
	Xil_ExceptionEnable();

	dev_irq_init();


	nvme_main();

	xil_printf("done\r\n");

	return 0;
}
