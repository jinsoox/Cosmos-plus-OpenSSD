


#include "xil_printf.h"
#include "debug.h"
#include "io_access.h"

#include "nvme.h"
#include "host_lld.h"
#include "nvme_io_cmd.h"


void handle_nvme_io_read(unsigned int cmdSlotTag, NVME_IO_COMMAND *nvmeIOCmd)
{
	IO_READ_COMMAND_DW12 readInfo12;
	//IO_READ_COMMAND_DW13 readInfo13;
	//IO_READ_COMMAND_DW15 readInfo15;
	unsigned int startLba[2];
	unsigned int nlb;
	unsigned int numOf4KB;
	unsigned int idxOf4KB;
	unsigned int devAddr;

	readInfo12.dword = nvmeIOCmd->dword[12];
	//readInfo13.dword = nvmeIOCmd->dword[13];
	//readInfo15.dword = nvmeIOCmd->dword[15];

	startLba[0] = nvmeIOCmd->dword[10];
	startLba[1] = nvmeIOCmd->dword[11];
	nlb = readInfo12.NLB;

	//if((nvmeIOCmd->PRP1[0] & 0xF) != 0 || (nvmeIOCmd->PRP2[0] & 0xF) != 0)
	//	xil_printf("RPRP: %X, %X, %X, %X\r\n", nvmeIOCmd->PRP1[1], nvmeIOCmd->PRP1[0], nvmeIOCmd->PRP2[1], nvmeIOCmd->PRP2[0]);

//	ASSERT(startLba[0] < STORAGE_CAPACITY_L && (startLba[1] < STORAGE_CAPACITY_H || startLba[1] == 0));
//	ASSERT(nlb < MAX_NUM_OF_NLB);
	ASSERT((nvmeIOCmd->PRP1[0] & 0xF) == 0 && (nvmeIOCmd->PRP2[0] & 0xF) == 0);
	ASSERT(nvmeIOCmd->PRP1[1] < 0x10 && nvmeIOCmd->PRP2[1] < 0x10);

	if((nvmeIOCmd->PRP1[0] & 0xFFF) != 0)
		xil_printf("rdCmd: %08X,%08X,%X,%X\r\n", nvmeIOCmd->PRP2[0], nvmeIOCmd->PRP1[0], startLba[0], nlb);
	//xil_printf("rdCmd: %08X,%08X,%X,%X\r\n", nvmeIOCmd->PRP2[0], nvmeIOCmd->PRP1[0], startLba[0], nlb);

	//devAddr = IO_DRAM_DATA_BUFFER + (startLba[0] * 4096);
	devAddr = IO_DRAM_DATA_BUFFER + ((startLba[0] * 4096) % MAX_IO_DATA_BUFFER); //hjyong
	
	numOf4KB = nlb;
	idxOf4KB = 0;
	while(idxOf4KB <= numOf4KB)
	{
		set_auto_tx_dma(cmdSlotTag, idxOf4KB, devAddr);
		//xil_printf("wr:%X, %X, %X\r\n", cmdSlotTag, idxOf4KB, devAddr);
		devAddr += 4096;
		idxOf4KB++;
	}
	//check_auto_tx_dma_done();
	//xil_printf("rdCmd done\r\n");

}

void handle_nvme_io_write(unsigned int cmdSlotTag, NVME_IO_COMMAND *nvmeIOCmd)
{
	IO_READ_COMMAND_DW12 writeInfo12;
	//IO_READ_COMMAND_DW13 writeInfo13;
	//IO_READ_COMMAND_DW15 writeInfo15;
	unsigned int startLba[2];
	unsigned int nlb;
	unsigned int numOf4KB;
	unsigned int idxOf4KB;
	unsigned int devAddr;

	writeInfo12.dword = nvmeIOCmd->dword[12];
	//writeInfo13.dword = nvmeIOCmd->dword[13];
	//writeInfo15.dword = nvmeIOCmd->dword[15];

	startLba[0] = nvmeIOCmd->dword[10];
	startLba[1] = nvmeIOCmd->dword[11];
	nlb = writeInfo12.NLB;

	//if((nvmeIOCmd->PRP1[0] & 0xF) != 0 || (nvmeIOCmd->PRP2[0] & 0xF) != 0)
	//	xil_printf("WPRP: %X, %X, %X, %X\r\n", nvmeIOCmd->PRP1[1], nvmeIOCmd->PRP1[0], nvmeIOCmd->PRP2[1], nvmeIOCmd->PRP2[0]);

//	ASSERT(startLba[0] < STORAGE_CAPACITY_L && (startLba[1] < STORAGE_CAPACITY_H || startLba[1] == 0));
//	ASSERT(nlb < MAX_NUM_OF_NLB);
	ASSERT((nvmeIOCmd->PRP1[0] & 0xF) == 0 && (nvmeIOCmd->PRP2[0] & 0xF) == 0);
	ASSERT(nvmeIOCmd->PRP1[1] < 0x10 && nvmeIOCmd->PRP2[1] < 0x10);

	if((nvmeIOCmd->PRP1[0] & 0xFFF) != 0)
		xil_printf("wrCmd: %08X,%08X,%X,%X\r\n", nvmeIOCmd->PRP2[0], nvmeIOCmd->PRP1[0], startLba[0], nlb);
	//xil_printf("wrCmd: %08X,%08X,%X,%X\r\n", nvmeIOCmd->PRP2[0], nvmeIOCmd->PRP1[0], startLba[0], nlb);

	//devAddr = IO_DRAM_DATA_BUFFER + (startLba[0] * 4096);
	devAddr = IO_DRAM_DATA_BUFFER + ((startLba[0] * 4096) % MAX_IO_DATA_BUFFER); //hjyong
	
	numOf4KB = nlb;
	idxOf4KB = 0;
	while(idxOf4KB <= numOf4KB)
	{
		set_auto_rx_dma(cmdSlotTag, idxOf4KB, devAddr);
		//xil_printf("wr:%X, %X, %X\r\n", cmdSlotTag, idxOf4KB, devAddr);
		devAddr += 4096;
		idxOf4KB++;
	}
	check_auto_rx_dma_done();
	//xil_printf("wrCmd done\r\n");

}

void handle_nvme_io_cmd(NVME_COMMAND *nvmeCmd)
{
	NVME_IO_COMMAND *nvmeIOCmd;
	NVME_COMPLETION nvmeCPL;
	unsigned int opc;

	nvmeIOCmd = (NVME_IO_COMMAND*)nvmeCmd->cmdDword;
	opc = (unsigned int)nvmeIOCmd->OPC;

	switch(opc)
	{
		case IO_NVM_FLUSH:
		{
			xil_printf("IO Flush Command\r\n");
			nvmeCPL.dword[0] = 0;
			nvmeCPL.specific = 0x0;
			set_auto_nvme_cpl(nvmeCmd->cmdSlotTag, nvmeCPL.specific, nvmeCPL.statusFieldWord);
			break;
		}
		case IO_NVM_WRITE:
		{
			//xil_printf("IO Write Command\r\n");
			handle_nvme_io_write(nvmeCmd->cmdSlotTag, nvmeIOCmd);
			break;
		}
		case IO_NVM_READ:
		{
			//xil_printf("IO Read Command\r\n");
			handle_nvme_io_read(nvmeCmd->cmdSlotTag, nvmeIOCmd);
			break;
		}
		default:
		{
			xil_printf("Not Support IO Command OPC: %X\r\n", opc);
			ASSERT(0);
			break;
		}
	}
	//xil_printf("ptr: %X\r\n", IO_READ32(0x70600100 + 0x04));

	
}

