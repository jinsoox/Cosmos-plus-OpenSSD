

#ifndef __NVME_IDENTIFY_H_
#define __NVME_IDENTIFY_H_

void identify_controller(unsigned int pBuffer);

void identify_namespace(unsigned int pBuffer);


#endif	//__NVME_IDENTIFY_H_
